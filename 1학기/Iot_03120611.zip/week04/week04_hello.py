name = input("Your name")
print(f"hellow {name}")